from pytgcalls import PyTgCalls
from core.userbot import userbot

call = PyTgCalls(userbot)
