import asyncio
import importlib
from pathlib import Path

from core.bot import bot
from core.userbot import userbot
from core.call import call
from database.db import init_db
import config

async def load_plugins():
    path = Path("plugins")
    for file in path.rglob("*.py"):
        if not file.name.startswith("__"):
            module_name = str(file).replace("/", ".").replace("\\", ".")[:-3]
            importlib.import_module(module_name)
            print(f"✅ Plugin dimuat: {module_name}")

async def main():
    print("Mempersiapkan Database...")
    await init_db()
    
    print("Menghidupkan Bot & Userbot...")
    await bot.start(bot_token=config.BOT_TOKEN)
    await userbot.start()
    
    print("Memuat Modul dan Navigasi...")
    await load_plugins()
    
    print("Mengaktifkan Sistem PyTgCalls...")
    await call.start()
    
    print("🚀 MusicBot Professional Berhasil Berjalan!")
    await asyncio.gather(
        bot.run_until_disconnected(),
        userbot.run_until_disconnected()
    )

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
